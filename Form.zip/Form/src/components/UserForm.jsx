import React, { useState } from "react";
import "./UserForm.css";

const initialFormData = {
  name: "",
  email: "",
  phone: "",
  age: "",
  gender: "",
  city: "",
  address: "",
  password: "",
};

function UserForm() {
  const [formData, setFormData] = useState(initialFormData);
  const [submittedData, setSubmittedData] = useState(null);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
 
  const totalFields = Object.keys(initialFormData).length;
  const filledFields = Object.values(formData).filter(
    (val) => val.trim() !== "",
  ).length;
  const progressPercent = Math.round((filledFields / totalFields) * 100);
 
  const getPasswordStrength = (pwd) => {
    if (!pwd) return { label: "Empty", score: 0, color: "#d1d5db" };
    let score = 0;
    if (pwd.length >= 6) score += 1;
    if (pwd.length >= 10) score += 1;
    if (/[0-9]/.test(pwd)) score += 1;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1;

    switch (score) {
      case 1:
        return { label: "Weak", score: 25, color: "#ef4444" };
      case 2:
        return { label: "Fair", score: 50, color: "#f59e0b" };
      case 3:
        return { label: "Good", score: 75, color: "#3b82f6" };
      case 4:
        return { label: "Strong", score: 100, color: "#10b981" };
      default:
        return { label: "Very Weak", score: 15, color: "#ef4444" };
    }
  };

  const passwordStrength = getPasswordStrength(formData.password);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (error) setError("");
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const requiredFields = [
      "name",
      "email",
      "phone",
      "age",
      "gender",
      "city",
      "address",
      "password",
    ];
    const hasEmptyField = requiredFields.some(
      (field) => formData[field].trim() === "",
    );

    if (hasEmptyField) {
      setError("Please fill in all the required fields.");
      setSubmittedData(null);
      return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(formData.email)) {
      setError("Please enter a valid email address.");
      setSubmittedData(null);
      return;
    }

    const phonePattern = /^[0-9]{10}$/;
    if (!phonePattern.test(formData.phone)) {
      setError("Please enter a valid 10-digit phone number.");
      setSubmittedData(null);
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must contain at least 6 characters.");
      setSubmittedData(null);
      return;
    }

    setError("");
    setIsSubmitting(true);

    // Simulate network submission delay for animation
    setTimeout(() => {
      setSubmittedData({ ...formData });
      setIsSubmitting(false);
    }, 600);
  };

  const handleReset = () => {
    setFormData(initialFormData);
    setSubmittedData(null);
    setError("");
  };

  return (
    <div className="form-page">
      <div className="form-container">
        {/* Header */}
        <div className="form-header">
          <span className="form-badge">⚡ Interactive Demo</span>
          <h1>User Registration Form</h1>
          <p>
            Complete your profile using real-time validation and active state
            tracking.
          </p>

          {/* Progress Indicator */}
          <div className="progress-wrapper">
            <div className="progress-info">
              <span>Form Completion</span>
              <strong>{progressPercent}%</strong>
            </div>
            <div className="progress-track">
              <div
                className="progress-bar"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Main Card */}
        <div className="form-card">
          <form onSubmit={handleSubmit} noValidate>
            <div className="form-grid">
              {/* Name */}
              <div className="form-group">
                <label htmlFor="name">
                  Full Name <span>*</span>
                </label>
                <div className="input-wrapper">
                  <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Jane Doe"
                    value={formData.name}
                    onChange={handleChange}
                  />
                  {formData.name && <span className="valid-tick">✓</span>}
                </div>
              </div>

              {/* Email */}
              <div className="form-group">
                <label htmlFor="email">
                  Email Address <span>*</span>
                </label>
                <div className="input-wrapper">
                  <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="jane@example.com"
                    value={formData.email}
                    onChange={handleChange}
                  />
                  {formData.email && <span className="valid-tick">✓</span>}
                </div>
              </div>

              {/* Phone */}
              <div className="form-group">
                <label htmlFor="phone">
                  Phone Number <span>*</span>
                </label>
                <div className="input-wrapper">
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    placeholder="9876543210"
                    maxLength="10"
                    value={formData.phone}
                    onChange={handleChange}
                  />
                  {formData.phone.length === 10 && (
                    <span className="valid-tick">✓</span>
                  )}
                </div>
              </div>

              {/* Age */}
              <div className="form-group">
                <label htmlFor="age">
                  Age <span>*</span>
                </label>
                <input
                  type="number"
                  id="age"
                  name="age"
                  placeholder="24"
                  min="1"
                  max="100"
                  value={formData.age}
                  onChange={handleChange}
                />
              </div>

              {/* Gender */}
              <div className="form-group">
                <label htmlFor="gender">
                  Gender <span>*</span>
                </label>
                <select
                  id="gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                  <option value="Prefer not to say">Prefer not to say</option>
                </select>
              </div>

              {/* City */}
              <div className="form-group">
                <label htmlFor="city">
                  City <span>*</span>
                </label>
                <select
                  id="city"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                >
                  <option value="">Select City</option>
                  <option value="Pune">Pune</option>
                  <option value="Bengaluru">Bengaluru</option>
                  <option value="Mumbai">Mumbai</option>
                  <option value="Delhi">Delhi</option>
                  <option value="Hyderabad">Hyderabad</option>
                  <option value="Chennai">Chennai</option>
                  <option value="Kolkata">Kolkata</option>
                  <option value="Ahmedabad">Ahmedabad</option>
                </select>
              </div>

              {/* Address */}
              <div className="form-group full-width">
                <label htmlFor="address">
                  Address <span>*</span>
                </label>
                <textarea
                  id="address"
                  name="address"
                  rows="3"
                  placeholder="Street address, apartment, suite..."
                  value={formData.address}
                  onChange={handleChange}
                />
              </div>

              {/* Password with Strength Indicator */}
              <div className="form-group full-width">
                <label htmlFor="password">
                  Password <span>*</span>
                </label>
                <div className="password-wrapper">
                  <input
                    type={showPassword ? "text" : "password"}
                    id="password"
                    name="password"
                    placeholder="Create a strong password"
                    value={formData.password}
                    onChange={handleChange}
                  />
                  <button
                    type="button"
                    className="toggle-password"
                    onClick={() => setShowPassword(!showPassword)}
                    tabIndex="-1"
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>

                {formData.password && (
                  <div className="strength-meter">
                    <div className="strength-bar-track">
                      <div
                        className="strength-bar-fill"
                        style={{
                          width: `${passwordStrength.score}%`,
                          backgroundColor: passwordStrength.color,
                        }}
                      />
                    </div>
                    <span
                      className="strength-label"
                      style={{ color: passwordStrength.color }}
                    >
                      Strength: {passwordStrength.label}
                    </span>
                  </div>
                )}
                <small>
                  Requires at least 6 characters, mixed with numbers or symbols.
                </small>
              </div>
            </div>

            {/* Error Notification */}
            {error && (
              <div className="error-message shake-anim">
                <span className="error-icon">!</span>
                <span>{error}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="button-container">
              <button
                type="button"
                className="reset-button"
                onClick={handleReset}
                disabled={isSubmitting}
              >
                Reset
              </button>

              <button
                type="submit"
                className={`submit-button ${isSubmitting ? "loading" : ""}`}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <span className="spinner" />
                ) : (
                  <>
                    <span>Submit Form</span>
                    <span className="arrow-icon">→</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Live Form State Display */}
        <div className="state-preview">
          <div className="section-title">
            <div className="pulse-dot" />
            <h2>Live State Inspector</h2>
          </div>

          <div className="state-grid">
            {Object.entries(formData).map(([key, val]) => (
              <div
                key={key}
                className={`state-item ${key === "address" ? "state-full" : ""} ${val ? "active" : ""}`}
              >
                <span>{key}</span>
                <strong>
                  {key === "password"
                    ? val
                      ? "•".repeat(val.length)
                      : "—"
                    : val || "—"}
                </strong>
              </div>
            ))}
          </div>
        </div>

        {/* Submission Result */}
        {submittedData && (
          <div className="submitted-card bounce-in">
            <div className="submitted-header">
              <div>
                <span className="success-badge">Success</span>
                <h2>Registration Complete</h2>
                <p>Record has been stored in client state.</p>
              </div>
              <div className="success-icon-box">✓</div>
            </div>

            <div className="submitted-grid">
              {Object.entries(submittedData).map(([key, val]) => (
                <div
                  key={key}
                  className={`data-box ${key === "address" ? "data-box-full" : ""}`}
                >
                  <span>{key}</span>
                  <strong>
                    {key === "password" ? "•".repeat(val.length) : val}
                  </strong>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default UserForm;
